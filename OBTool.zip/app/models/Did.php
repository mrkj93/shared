<?php

require_once 'app/core/Database.php';

class Did {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function getAllDid() {
        $sql = "SELECT id, groupid, did, status, telco_type, descr, last_modified FROM hotline";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

?>