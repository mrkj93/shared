<?php

class RedisClient {
    private $redis;

    public function __construct() {
        $this->redis = new Redis();
        $this->redis->connect('127.0.0.1', 6379);
    }

    public function get($key) {
        return $this->redis->get($key);
    }

    public function set($key, $value) {
        return $this->redis->set($key, $value);
    }
}

?>