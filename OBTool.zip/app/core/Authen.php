<?php

class Authen {
    private $userAuth;
    private $passAuth;
    private $config;

    public function __construct(array $config, $userAuth, $passAuth) {
        $this->userAuth = $userAuth;
        $this->passAuth = $passAuth;
        $this->config = $config;
    }

    public function authentication() {
        $arrAuthen = array();
        $ipAddr = $this->getClientIP();

        $arrIP = $this->config['allowIP'];

        if (in_array($ipAddr, $arrIP) || in_array("all", $arrIP)) {
            if (strcmp($this->userAuth, $this->config['userUCCE']) == 0 && strcmp($this->passAuth, $this->config['passUCCE']) == 0) {
                $arrAuthen['status'] = 1;
                $arrAuthen['result'] = $ipAddr;
            } else {
                $arrAuthen['status'] = 2;
                $arrAuthen['result'] = "Username/Password Incorrect";
            }
        } else {
            $arrAuthen['status'] = 3;
            $arrAuthen['result'] = "Do not allow IP address";
        }

        return $arrAuthen;
    }

    public function getClientIP() {
        $ipAddr = "";
        if (isset($_SERVER['HTTP_CLIENT_IP'])) $ipAddr = $_SERVER['HTTP_CLIENT_IP'];
        else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) $ipAddr = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if (isset($_SERVER['HTTP_X_FORWARDED'])) $ipAddr = $_SERVER['HTTP_X_FORWARDED'];
        else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) $ipAddr = $_SERVER['HTTP_FORWARDED_FOR'];
        else if (isset($_SERVER['HTTP_FORWARDED'])) $ipAddr = $_SERVER['HTTP_FORWARDED'];
        else if (isset($_SERVER['REMOTE_ADDR'])) $ipAddr = $_SERVER['REMOTE_ADDR'];
        else $ipAddr = "UNKNOWN";
        return $ipAddr;
    }
}

?>