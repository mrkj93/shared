<?php

require_once 'Database.php';

class ApiLog extends Database {
    public function writeLog($table, $arrRequest) {
        $idRequestAPI = $this->add($table, $arrRequest);
        return $idRequestAPI;
    }

    public function updateLog($sqlUpdate) {
        $idUpdate = $this->doUpdate($sqlUpdate);
        return $idUpdate;
    }
}

?>
