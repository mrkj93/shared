<?php

class mysqlPDO{
   
	private $con,$error,$traceError=1,$host,$user,$password,$db;

	function __construct($hostname,$username,$password,$dbname){
		$this->host = $hostname;
		$this->user = $username;
		$this->password = $password;
		$this->db = $dbname;
		$this->error = array();
		try{
			$this->con = new PDO ("mysql:host=$this->host;dbname=$this->db","$this->user","$this->password");
			$this->con->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		}catch(PDOException $e){
			$this->reconnect();
			throw $e;
		}
	}

	
	public function getHost(){
		return $this->host;
	}
   
	public function getUser(){
		return $this->user;
	}
	
	public function getPass(){
		return $this->password;
	}
	
	public function getDB(){
		return $this->db;
	}
	
	public function setErrorReporting($status){
		$this->traceError = $status;	
	}

	public function doSelect($sql){
		try{
			$stmt = $this->con->prepare($sql);
			$stmt->execute();
			return $stmt->fetchAll();
		}catch(PDOException $e){
			$this->reconnect();
			throw $e;
		}
	}

	public function doSelectAssoc($sql){
		try{
			$stmt = $this->con->prepare($sql);
			$stmt->execute();
			return $stmt->fetchAll(PDO::FETCH_ASSOC);
		}catch(PDOException $e){
			$this->reconnect();
			throw $e;
		}
	}
	
	public function doSelectNum($sql){
		try{
			$stmt = $this->con->prepare($sql);
			$stmt->execute();
			return $stmt->fetchAll(PDO::FETCH_NUM);
		}catch(PDOException $e){
			$this->reconnect();
			throw $e;
		}
	}
		
	public function doSelectOne($sql){
		try{
			$stmt = $this->con->prepare($sql);
			$stmt->execute();
			$data = $stmt->fetch();
			if($data) return $data;
		}catch(PDOException $e){
			$this->reconnect();
			throw $e;
		}
	}

	public function count($sql){
		try {
			$stmt = $this->con->prepare($sql);
			$stmt->execute();
			return $stmt->fetchColumn();
		} catch (PDOException $e) {
			$this->reconnect();
			throw $e;
		}
	}

	public function getLastInsertId(){
		return $this->con->lastInsertId();
	}

	public function doUpdate($sql){
		try{
			$this->con->exec($sql);
			if($this->getLastInsertId()) return $this->getLastInsertId();
			else return true;
		}catch(PDOException $e){
			$this->reconnect();
			throw $e;
		}
	}


// array_values  = array('username'=>$username,'password'=>$password)
// string_values = ('','');
	public function add($table,$arr_values){
		try{
			if(is_array($arr_values)){
				$sqlInsert = "INSERT INTO {$table}(";
				$sqlValue = ") VALUES('";
				$str_tables = implode(",",array_keys($arr_values));
				$str_values = implode("','",array_values($arr_values));					
				$sqlInsert .= $str_tables.$sqlValue.$str_values."')";
				$sqlInsert = str_replace("'NOW()'","NOW()",$sqlInsert);
				$sqlIn = str_replace("'NULL'","NULL",$sqlInsert);
				//echo $sqlIn; exit;
				$id = $this->doUpdate($sqlIn);
				//echo "ID = ".$id;
				return $id;
			}
		}catch(Exception $e){
			$this->reconnect();
			throw $e;
		}
	}

// $array_values = array(array('username'=>$username,'password'=>$password),array('username'=>$username1,'password'=>$password1))
// string_values = ('',''),('','')
	public function multisAdd($table,$arr_values){
		try{
			if(is_array($arr_values)){
				$sqlInsert = "INSERT INTO {$table}(";
				$sqlValue = ") VALUES";
				$str_tables = implode(",",array_keys($arr_values[0]));
				$str_start = "('";
				$str_end =  "')";
				$str_values = $str_start.implode("','",array_values($arr_values[0])).$str_end;				
				for($i=1; $i<count($arr_values); $i++){
					$str_values .= ",".$str_start.implode("','",array_values($arr_values[$i])).$str_end; 
				}					
				$sqlInsert .= $str_tables.$sqlValue.$str_values;
				$sqlInsert = str_replace("'NOW()'","NOW()",$sqlInsert);
				//echo "SQL = ".$sqlInsert; exit();
				$this->doUpdate($sqlInsert);
				return $this->getLastInsertId();
			}
		}catch(Exception $e){
			$this->reconnect();
			throw $e;
			//if($this->$traceError) echo $e->getMessage();
			//return false;
		}
	}

	public function update($data,$table,$conndition){
		try{
			if(is_array($data)){
				$i=0;
				$sqlField = "";
				foreach($data as $key=>$value){
					$value = str_replace("'","\'",$value);
					if($i){
						$sqlField .= ",".$key."='".$value."'";
					}
					else{
						$sqlField .= $key."='".$value."'";
						$i++;
					}
				}

				$sql = "UPDATE {$table} set {$sqlField} WHERE {$conndition} ";
				//echo $sql;
				return $this->doUpdate($sql);
			}
			else {
				return false;
			}
		} catch(Exception $e){
			$this->reconnect();
			throw $e;
		}
	}

	public function delete($table,$condition){
		try{
			$sql = "DELETE FROM {$table} WHERE {$condition} ";
			return $this->doUpdate($sql);
		}catch(Exception $e){
			$this->reconnect();
			throw $e;
		}
	}

	public function getConnection() {
        if ($this->con === null) {
            $this->reconnect();
        }
        return $this->con;   
    }
 
    public function reconnect() {
		$hostname = $this->getHost();
		$dbname = $this->getDB();
		$username = $this->getUser();
		$password = $this->getPass();
		$this->con = new PDO ("mysql:host=$this->host;dbname=$this->db","$this->user","$this->password");
        //$this->con = new PDO($this->dsn, $this->username, $this->password, $this->options);
    }

	public function AddMulti($table,$arr_values){
                try{
                        if(is_array($arr_values)){
                                $sqlInsert = "INSERT INTO {$table}(";
                                $sqlValue = ") VALUES";
                                $str_tables = implode(",",array_keys($arr_values[0]));
                                $str_start = "('";
                                $str_end =  "')";
                                $str_values = $str_start.implode("','",array_values($arr_values[0])).$str_end;
                                for($i=1; $i<count($arr_values); $i++){
                                        $str_values .= ",".$str_start.implode("','",array_values($arr_values[$i])).$str_end;
                                }
                                $sqlInsert .= $str_tables.$sqlValue.$str_values;
                                $sqlInsert = str_replace("'NOW()'","NOW()",$sqlInsert);
                                echo "SQL = ".$sqlInsert; exit();
                                $this->doUpdate($sqlInsert);
                                return $this->getLastInsertId();
                        }
                }catch(Exception $e){
                        $this->reconnect();
                        throw $e;
                        //if($this->$traceError) echo $e->getMessage();
                        //return false;
                }
        }
   
   
	public function getError(){
		return $this->error;
	}

	public function closeConnection(){
		$this->con = NULL;
	}
}

?>
