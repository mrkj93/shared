<?php

class apiController {
    private $requestMethod;
    private $uri;
    private $config;

    public function __construct(array $config, $requestMethod, $uri) {
        $this->requestMethod = $requestMethod;
        $this->uri = $uri;
        $this->config = $config;
    }

    public function processRequest() {
        switch ($this->requestMethod) {
            case 'POST':
                if ($this->uri[2] == 'OB_CheckDid') {
                    $this->getDidList();
                } else {
                    $response = $this->notFoundResponse();
                }
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }

        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }

    public function getDidList() {
        $arrData = json_decode(file_get_contents('php://input'), true);

        // Authentication
        $authenObj = new authen($this->config, $arrData['userauth'], $arrData['passauth']);
        $arrAuthen = $authenObj->authentication();

        if ($arrAuthen['status'] == 1) {
            // Log the request
            $apiLogObj = new apilog($this->config['hostDB'], $this->config['userDB'], $this->config['passDB'], $this->config['nameDB']);
            $idRequest = $apiLogObj->writelog("api_log", $arrData);

            // Get DID list
            $didModel = new Did();
            $redis = new RedisClient();

            $cacheKey = 'did_list';
            $didList = $redis->get($cacheKey);

            if (!$didList) {
                $didList = $didModel->getAll();
                $redis->set($cacheKey, json_encode($didList));
            } else {
                $didList = json_decode($didList, true);
            }

            // Log the response
            $responseJson = json_encode($didList);
            $sqlUpApiLog = "UPDATE api_log SET response_time = NOW(), response_data = '$responseJson' WHERE id = '$idRequest'";
            $apiLogObj->updatelog($sqlUpApiLog);

            $apiLogObj->closeConnection();

            $this->renderJson($didList);
        } else {
            $result = '{"error_code": "300", "result": "Authentication fail"}';
            $response = $this->successResponse($result);
            header($response['status_code_header']);
            if ($response['body']) {
                echo $response['body'];
            }
        }
    }

    public function notFoundResponse() {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = null;
        return $response;
    }

    public function successResponse($result) {
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = $result;
        return $response;
    }

    public function renderJson($data) {
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    public function removeJsonEscapes($value) {
        if (is_string($value)) {
            $decoded = json_decode($value);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
        }
        return $value;
    }
}
?>
