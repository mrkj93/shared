<?php

	return [
		'hostDB' => '10.37.8.90',
		'userDB' => 'root',
		'passDB' => 'Vpb@2024',
		'nameDB' => 'vpboutbound',
		'allowIP' => ['127.0.0.1','all'],
		'userUCCE' => 'cvpapi',
		'passUCCE' => '8R3}I|6L6bcB',
		// 'token' => 'dXNlcnRlc3Q6QWJjQDEyMw==',
	];

?>
