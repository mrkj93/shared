<?php

require_once 'config.php';
require_once 'app/core/Database.php';
require_once 'app/core/RedisClient.php';
require_once 'app/core/Authen.php';
require_once 'app/core/ApiLog.php';
require_once 'app/controllers/DidController.php';

// Lấy URI và kiểm tra
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode('/', $uri);

if ($uri[1] !== 'OBTool') {
    header("HTTP/1.1 404 Not Found");
    exit();
}

// Lấy thông tin xác thực từ header
//$userAuth = isset($_SERVER['PHP_AUTH_USER']) ? $_SERVER['PHP_AUTH_USER'] : '';
//$passAuth = isset($_SERVER['PHP_AUTH_PW']) ? $_SERVER['PHP_AUTH_PW'] : '';

// Xác thực
$config = require 'config.php';
$authen = new Authen($config, $userAuth, $passAuth);
$authResult = $authen->authentication();

if ($authResult['status'] !== 1) {
    header("HTTP/1.1 403 Forbidden");
    echo json_encode($authResult);
    exit();
}

// Gọi controller dựa trên method và URI
$requestMethod = $_SERVER['REQUEST_METHOD'];
$controller = new DidController($config, $requestMethod, $uri);
$controller->processRequest();

?>